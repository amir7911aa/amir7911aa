var _0xfa96 = ["language", "userLanguage", "null", "", "command", "auth", "game_status", "cash_out", "error", "broadcast",
 "last_win", "waiting", "started", "update", "busted", "chips", "chat", "play", "finish", "cancel", "mute", "top_winners", 
 "uid", "cashin", "amount", "cashout", "val", ".game-amount", "toFixed", ".cashout-amount", "∞", "im_in_game", "name", "push", 
 "players", "length", ".history-container .table-body .crash-row", "current", "html", ".h-col-2", "children", "first", "won", 
 ".h-col-4", "splice", "winners", "photo", "currency", "admin", "default_amount", "photo_image", "onload", "src", "attr", 
 ".profile_photo", "onerror", ".user-name", ".chips-amount", "lobby_screen", ".top_left_chips", "game_screen", "status",
  "time", "setWaiting", "setPlaying", "setBusted", "maximum_text", "crash_top_winners", "data", "i", "winner_text", "  @", 
  "loser_text", "other_text", ".chat-container", ".users-list-container", ".history-container .table-body", "sort", "chats",
   "<div class="chat-row"><div><span>", "</span></div><div class="txt">", "text", "</div></div>",    "<a href="javascript:;" class="mute-user-button" data="", "" style="text-decoration: none; text-align: center; display:inline-block; background: red; color: #fff; font-weight: bold; width: 16px; height: 16px; border-radius: 8px; padding: 2px; margin: 4px;">x</a><span style="color: #000;"> &nbsp; ",
    " &nbsp; </span>", "<div class="chat-row chat-uid-", ""><div><span>", "</span></div><div class="txt" style="color: red; font-size: 14px;">",
     "append", "scrollTop", "scrollHeight", "prop", "crashes", "crash", "<div class="crash-row"><div class="col bold h-col-1 ", 
     "c-green", "c-red", "">", "</div><div class="col h-col-2">-</div><div class="col h-col-3">-</div><div class="col h-col-4">-</div><div class="col h-col-5"><a href="javascript:;" class="show-code">", "md5",
      "</a></div><div class="col h-col-6"><a href="javascript:;" class="show-code">", "hash", "</a></div><div class="clear"></div></div>",
       "prepend", ".crash-", "<div class="crash-row crash-", ""><div class="col bold h-col-1">-</div><div class="col h-col-2">-</div><div class="col h-col-3">-</div><div class="col h-col-4">-</div><div class="col h-col-5"><a href="javascript:;" class="show-code">", "</a></div><div class="col h-col-6">-</div><div class="clear"></div></div>", "autoplay", "join", ",", "split", ".", "-", ""><div class="col bold h-col-1">-</div><div class="col h-col-2">-</div><div class="col h-col-3">", "</div><div class="col h-col-4">-</div><div class="col h-col-5"><a href="javascript:;" class="show-code">", " .h-col-3", "remove", "last", " .h-col-1", "addClass", "<a href="javascript:;" class="show-code">", "</a>", " .h-col-6", ".chat-container .chat-row", "height", ".chat-panel .container", ".chat-uid-", "message", "{name}", "replace", "last_winner", "{amount}", "#last_winner", "css", "show", "animate", "shift", "start", "click", "unbind", ".mute-user-button", "</span>", "parent", ".txt", "find", "<font style='font-size:20px;'><font style='font-weight: bold;'>", "</font> (", ")<br>", "</font>", "warning", "#DD6B55", "okey", ".show-code", "hide", ".screen", "#", ".background", "width", "loading_screen", "set_game", "load", "getTime", "setTime", "; expires=", "toGMTString", "cookie", "=", "; path=/", ";", " ", "charAt", "substring", "indexOf", "lang", "device", "game", "reload", "location", "fail", "object", "parse", "result", "done", "post", "OK", "<font style='font-size:20px;'>", "user/casino/language", "main_disconnect", ".lang_31", "main_connect_again", ".lang_32", "landscape", ".lang_46", "crash_play", ".lang_57", "crash_rules", ".lang_60", "crash_fair", ".lang_61", "crash_exit", ".lang_62", "crash_betpanel", ".lang_63", "crash_amount", ".lang_64", "crash_autocashout", ".lang_65", "crash_placebet", ".lang_66", "crash_history", ".lang_67", "crash_chat", ".lang_68", "crash_players", ".lang_69", "crash_user", ".lang_70", "crash_bet", ".lang_71", "crash_profit", ".lang_72", "crash_crash", ".lang_73", "crash_md5", ".lang_74", "crash_hash", ".lang_75", ".lang_80", "nextround_text", "crash_next", "busted_title", "crash_busted", "javascript", "assets", "list", "image", "assets/back.png", "assets/button_red.png?", "assets/exit.png", "assets/home.png", "assets/lamp-light.png", "assets/lamp.png", "assets/landscape.png", "assets/placeholder.png", "assets/screen-light.png", "assets/screen.png", "assets/zoomout.png", "clean_name", "/", "total_assets", ".loading_bar", "#loading_indicator", "url", "type", "sound", "onloadeddata", "get", "substr", "formatMoney", "prototype", "abs", "$1", "slice", "ios", "assets/sounds/", ".mp3", "seekTo", "sound_", "getElementById", "readyState", "currentTime", "close", "onopen", "onmessage", "onclose", "disconnect_screen", "stringify", "send", "token", "disabled", "removeAttr", ".range-slide", "rangeslider", "cashin_amount", "place-bet-cashout", "removeClass", ".place-bet", "place-bet-passive", "place-bet-cancel", "crash_cancel", "crash_cashout", "<br><span class='cashout-amount-text'>0</span>", "<br><span style='font-size: 12px;'>", "crash_join_next", "width: 0%;", ".status-red-bar", ".status-green-bar", "width: 100%;", ".status-yellow-bar", "<div class="c-yellow"><div class="col col-1">", "</div><div class="col col-2">-</div><div class="col col-3">", "</div><div class="col col-5">-</div><div class="clear"></div></div>", "width: ", "%;", "<div class="c-green"><div class="col col-1">", "</div><div class="col col-2">", "</div><div class="col col-3">", "</div><div class="col col-5">", "</div><div class="clear"></div></div>", "<div class="c-red"><div class="col col-1">", "error-box", ".cashout-amount-box", "graph", "init", "user/casino/auth", "ok", "bets", "address", ".home_button", ".refresh_button", "cash_in", "#play_button", ".cashout-button", ".game-amount-box", "keyup", "input", ".rangeslider__handle", "nextSibling", "target", "value", "on", "#chat-input-text", ".chat-send", "tab-active", ".game-bottom .tab-container .tab-active", ".history-button", ".game-bottom .other-panels .user-container", ".game-bottom .chat-panel", ".game-bottom .other-panels .history-container", ".game-bottom .other-panels", ".chat-button", ".players-button", ".user-container .table-body", ".make-double", "resize", "ready", "start_time", "started_time", "time_passed", "current_amount", "texts", "Max profit: {amount} BTC", "Winner bonus: {amount} BTC", "Loser bonus: {amount} BTC", "Next round in {time}s", "Busted", "warning_text", "busted_amount", "busted_text", "time_part", "amount_part", "graph_part", "canvas_size", "coors", "dark_style", "setLanguage", "maximum", "winner", "loser", "nextround", "setAmounts", "setWarning", "canvas", "context", "2d", "getContext", "rtimer", "render", "requestAnimationFrame", "devicePixelRatio", "webkitBackingStorePixelRatio", "mozBackingStorePixelRatio", "msBackingStorePixelRatio", "oBackingStorePixelRatio", "backingStorePixelRatio", "style", "px", "scale", "clearRect", "draw", "origin", "info", "profit", "axis", "drawAxis", "drawMaximum", "drawAxisLabels", "drawWaiting", "drawGraph", "drawAmount", "price", ".cashout-amount-text", "drawBusted", "drawWarning", "lineWidth", "strokeStyle", "#b0b3c1", "#7f7f7f", "beginPath", "x", "moveTo", "y", "lineTo", "stroke", "closePath", "fillStyle", "#555", "textAlign", "left", "font", "px Barlow", "y1", "fillText", "#69ca5e", "y2", "#e27474", "y3", "#6ca7d2", "y4", "0.0", "#ccc", "center", "{time}", "#fff", "#000", "ceil", "ty", "ly", "right", "pow", "tx", "th", "lx", "#408609", "#c3b407", "black", "@ ", "red", "line1", "line2", "rgba(0,0,0,0.4)", "rect", "fill", "by", "bh", "#graph-container", "#graph", ".game-controls", "calc(100% - ", "px)", ".game-bottom"];
var userLang = navigator[_0xfa96[0]] || navigator[_0xfa96[1]], language, game_assets, user_data = new Object, game_data = new Object({
    status: _0xfa96[2],    cashin: !1,    amount: 0,    cashout: 0,    winners: [,    players: [,    autoplay: }), top_winners = [], last_winners = [], last_winners_bussy = !1, screen_size = new Object, socket_connection, active_screen = _0xfa96[3], mute_audios = !1;
if (void (0) = debug_level) {    var debug_level = 0};data_from_socket = function(_0x8341xe) {    var _0x8341xf = null != _0x8341xe[_0xfa96[4]] ? _0x8341xe[_0xfa96[4]] : _0xfa96[3];
    _0xfa96[5] == _0x8341xf && game_auth(_0x8341xe),    _0xfa96[6] == _0x8341xf && game_status(_0x8341xe),    _0xfa96[7] == _0x8341xf && game_cash_out(_0x8341xe),    _0xfa96[8] == _0x8341xf && game_error(_0x8341xe),
    _0xfa96[9] == _0x8341xf && game_broadcast(_0x8341xe),    _0xfa96[10] == _0x8341xf && game_last_win(_0x8341xe),    _0xfa96[11] == _0x8341xf && game_waiting(_0x8341xe),    _0xfa96[12] == _0x8341xf && game_started(_0x8341xe),
    _0xfa96[13] == _0x8341xf && game_update(_0x8341xe),    _0xfa96[14] == _0x8341xf && game_busted(_0x8341xe),    _0xfa96[15] == _0x8341xf && game_chips(_0x8341xe),    _0xfa96[16] == _0x8341xf && game_chat(_0x8341xe),
    _0xfa96[17] == _0x8341xf && game_play(_0x8341xe),    _0xfa96[18] == 0x8341xf && game_finish(_0x8341xe),    _0xfa96[19] == _0x8341xf && game_cancel(_0x8341xe),    _0xfa96[20] == _0x8341xf && game_mute(_0x8341xe),
    _0xfa96[21] == _0x8341xf && game_top_winners(_0x8341xe)},game_play = function(_0x8341xe) {    user_data['uid'] == _0x8341xe[_0xfa96[22]]     &&
     (    game_data['cashout'] = _0x8341xe[_0xfa96[25]],    $(_0xfa96[27]).val(chip_format_no_symbol(game_data['amount'])),    $(_0xfa96[29]).val((game_data['cashout'] / 100)[_0xfa96[28]](2)),
    1e6 == game_data['cashout'] && $(_0xfa96[29]).val(_0xfa96[30]),    update_button(),    gameCanvas[_0xfa96[31]] = !0    ),
    game_data[_0xfa96[34]][_0xfa96[33]]({        uid: _0x8341xe[_0xfa96[22]],        amount: _0x8341xe[_0xfa96[24]],        name: _0x8341xe[_0xfa96[32]],
        cashout: _0x8341xe[_0xfa96[25]]    }),    prepare_user_list()},game_finish = function(_0x8341xe) {    for (i in user_data['uid'] == _0x8341xe[_0xfa96[22]] && (game_data[_0xfa96[23]] = !1,
    gameCanvas[_0xfa96[31]] = !1,    update_button(),    $(_0xfa96[36]).length > 0 && ($(_0xfa96[36])[_0xfa96[41]]()[_0xfa96[40]](_0xfa96[39])[_0xfa96[38]]((_0x8341xe[_0xfa96[37]] / 100)[_0xfa96[28]](2)),
    $(_0xfa96[36])[_0xfa96[41]]()[_0xfa96[40]](_0xfa96[43])[_0xfa96[38]](chip_format_no_symbol(_0x8341xe[_0xfa96[42]] - _0x8341xe[_0xfa96[24]])))),
    game_data[_0xfa96[34]]) {        if (game_data[_0xfa96[34]][i][_0xfa96[22]] == _0x8341xe[_0xfa96[22]]) {            game_data[_0xfa96[34]][_0xfa96[44]](i, 1);
            break        }    }    ;game_data[_0xfa96[45]][_0xfa96[33]]({        uid: _0x8341xe[_0xfa96[22]],        amount: _0x8341xe[_0xfa96[24]],
        cashout: _0x8341xe[_0xfa96[37]],        won: _0x8341xe[_0xfa96[42]],        name: _0x8341xe[_0xfa96[32]]    }),    prepare_user_list()}
,    for (i in user_data['uid'] == _0x8341xe[_0xfa96[22]] && (game_data[_0xfa96[23]] = !1,    gameCanvas[_0xfa96[31]] = !1,
    update_button()),    game_data[_0xfa96[34]]) {        if (game_data[_0xfa96[34]][i][_0xfa96[22]] == _0x8341xe[_0xfa96[22]]) {
            game_data[_0xfa96[34]][_0xfa96[44]](i, 1);            break        }    }    ;prepare_user_list()},game_auth = function(_0x8341xe) {
    user_data['uid'] = _0x8341xe[_0xfa96[22]],    user_data['name'] = _0x8341xe[_0xfa96[32]],    user_data['photo'] = _0x8341xe[_0xfa96[46]],
    user_data['chips'] = _0x8341xe[_0xfa96[15]],    user_data['currency'] = _0x8341xe[_0xfa96[47]],    user_data['admin'] = null != _0x8341xe[_0xfa96[48]] && _0x8341xe[_0xfa96[48]],    $(_0xfa96[27]).val(chip_format_no_symbol(_0x8341xe[_0xfa96[49]])),
    _0xfa96[3] != user_data['photo'] && (user_data[_0xfa96[50]] = new Image,    user_data[_0xfa96[50]][_0xfa96[51]] = function() {
        $(_0xfa96[54])[_0xfa96[53]](_0xfa96[52], user_data['photo'])    }    ,    user_data[_0xfa96[50]][_0xfa96[55]] = function() {}    ,
    user_data[_0xfa96[50]][_0xfa96[52]] = user_data['photo']),    $(_0xfa96[56])[_0xfa96[38]](user_data['name']),    $(_0xfa96[57])[_0xfa96[38]](short_chip_format(user_data['chips'])),    change_screen(_0xfa96[58])
},game_status = function(_0x8341xe) {    if (null != _0x8341xe[_0xfa96[15]] && user_data['chips'] = _0x8341xe[_0xfa96[15]],
    $(_0xfa96[59])[_0xfa96[38]](short_chip_format(user_data['chips']))),    gameCanvas[_0xfa96[31]] = !1,
    fadein_screen(_0xfa96[60]),    resize_screen(),    _0xfa96[11] == _0x8341xe[_0xfa96[61]]) {        game_data[_0xfa96[61]] = _0xfa96[11],
        gameCanvas[_0xfa96[63]](_0x8341xe[_0xfa96[62]])    } else {        if (_0xfa96[12] == _0x8341xe[_0xfa96[61]]) {
            game_data[_0xfa96[61]] = _0xfa96[12],            gameCanvas[_0xfa96[64]](_0x8341xe[_0xfa96[62]])
        } else {            if (_0xfa96[14] == _0x8341xe[_0xfa96[61]]) {                game_data[_0xfa96[61]] = _0xfa96[14];
                var _0x8341xf = (_0x8341xe[_0xfa96[24]] / 100)[_0xfa96[28]](2);                gameCanvas[_0xfa96[65]](_0x8341xf, _0x8341xe[_0xfa96[62]])
            }        }    }    ;if (_0x8341xe[_0xfa96[21]]) {        for (i in gameCanvas[_0xfa96[66]] = language[_0xfa96[68]][_0xfa96[67]],
        top_winners = _0x8341xe[_0xfa96[21]]) {            var _0x8341x10 = (top_winners[i][_0xfa96[25]] / 100)[_0xfa96[28]](2);
            0 == top_winners[i][_0xfa96[69]] && (gameCanvas[_0xfa96[70]] = short_chip_format(top_winners[i][_0xfa96[42]]) + _0xfa96[71] + _0x8341x10 + _0xfa96[71] + top_winners[i][_0xfa96[32]]),
            1 == top_winners[i][_0xfa96[69]] && (gameCanvas[_0xfa96[72]] = short_chip_format(top_winners[i][_0xfa96[42]]) + _0xfa96[71] + _0x8341x10 + _0xfa96[71] + top_winners[i][_0xfa96[32]]),
            2 == top_winners[i][_0xfa96[69]] && (gameCanvas[_0xfa96[73]] = short_chip_format(top_winners[i][_0xfa96[42]]) + _0xfa96[71] + _0x8341x10 + _0xfa96[71] + top_winners[i][_0xfa96[32]])
 ,message = function(_0x8341xe) {    var _0x8341xf = null != language && null != language[_0xfa96[68]] && null != language[_0xfa96[68]][_0xfa96[153]] ? language[_0xfa96[68]][_0xfa96[153]] : _0xfa96[186];
    swal({        text: _0xfa96[187] + _0x8341xe + _0xfa96[150],        confirmButtonText: _0x8341xf,;var lang = function() {    this[_0xfa96[162]] = function(_0x8341xe) {        var _0x8341xf = new Object;        _0x8341xf[_0xfa96[175]] = userLang;
        var _0x8341x10 = readCookie(_0xfa96[0]);        return null != _0x8341x10 && (_0x8341xf[_0xfa96[0]] = _0x8341x10),
        apiRequest(_0xfa96[188], _0x8341xf, function(_0x8341xf, _0x8341x10) {
            null != _0x8341x10[_0xfa96[68]] && (language[_0xfa96[68]] = _0x8341x10[_0xfa96[68]]),
            null != _0x8341xe && _0x8341xe()              this[_0xfa96[349]] = (new Date)[_0xfa96[163]]() - _0x8341xf,
        this[_0xfa96[350]] = _0x8341xf    }    ,    this[_0xfa96[315]] = function(_0x8341xe, _0x8341xf) {
        this[_0xfa96[374]] = document[_0xfa96[270]](_0x8341xe),        this[_0xfa96[375]] = this[_0xfa96[374]][_0xfa96[377]](_0xfa96[376]),
        this[_0xfa96[364]] = _0x8341xf,        this[_0xfa96[346]](),        this[_0xfa96[378]] = !0,        window[_0xfa96[380]](gameCanvas[_0xfa96[379]])
    this[_0xfa96[346]] = function(_0x8341xe) {        null != _0x8341xe && (this[_0xfa96[364]] = _0x8341xe);        var _0x8341xf = (window[_0xfa96[381]] || 1) / (this[_0xfa96[375]][_0xfa96[382]] || this[_0xfa96[375]][_0xfa96[383]] || this[_0xfa96[375]][_0xfa96[384]] || this[_0xfa96[375]][_0xfa96[385]] || this[_0xfa96[375]][_0xfa96[386]] || 1);
        this[_0xfa96[374]][_0xfa96[159]] = this[_0xfa96[364]][_0xfa96[159]] * _0x8341xf,
        this[_0xfa96[374]][_0xfa96[126]] = this[_0xfa96[364]][_0xfa96[126]] * _0x8341xf,
        this[_0xfa96[374]][_0xfa96[387]][_0xfa96[159]] = this[_0xfa96[364]][_0xfa96[159]] + _0xfa96[388],
        this[_0xfa96[374]][_0xfa96[387]][_0xfa96[126]] = this[_0xfa96[364]][_0xfa96[126]] + _0xfa96[388],
        this[_0xfa96[375]][_0xfa96[389]](_0x8341xf, _0x8341xf),        this[_0xfa96[365]] = null    }    ,    this[_0xfa96[379]] = function() {
        if (!gameCanvas[_0xfa96[378]]) {            return !1        }        ;gameCanvas[_0xfa96[375]][_0xfa96[390]](0, 0, gameCanvas[_0xfa96[364]][_0xfa96[159]], gameCanvas[_0xfa96[364]][_0xfa96[126]]),
        gameCanvas[_0xfa96[391]](gameCanvas[_0xfa96[375]]),        window[_0xfa96[380]](gameCanvas[_0xfa96[379]])
    }    ,    this[_0xfa96[391]] = function(_0x8341xe) {        if (null == this[_0xfa96[365]]) {
            this[_0xfa96[365]] = {                width: this[_0xfa96[364]][_0xfa96[159]],                height: this[_0xfa96[364]][_0xfa96[126]]            };            var _0x8341xf = nr(0.08 * this[_0xfa96[364]][_0xfa96[159]])
              , _0x8341x10 = nr(this[_0xfa96[364]][_0xfa96[126]] - 0.07 * this[_0xfa96[364]][_0xfa96[126]]);
            this[_0xfa96[365]][_0xfa96[392]] = {                x: _0x8341xf,
                y: _0x8341x10            };
            var _0x8341x11 = nr(0.1 * this[_0xfa96[364]][_0xfa96[126]])
              , _0x8341x18 = nr((this[_0xfa96[365]][_0xfa96[159]] + _0x8341xf) / 2)
              , _0x8341x12 = nr(0.48 * this[_0xfa96[365]][_0xfa96[126]])
              , _0x8341x13 = nr(0.36 * this[_0xfa96[365]][_0xfa96[126]])
              , _0x8341x14 = nr(1.7 * _0x8341x11);
            this[_0xfa96[365]][_0xfa96[393]] = {                x: _0x8341x18,
                y: _0x8341x12,
                font: _0x8341x11,
                by: _0x8341x13,
                bh: _0x8341x14
            };
            var _0x8341x15 = nr(0.22 * this[_0xfa96[364]][_0xfa96[126]])
              , _0x8341x16 = nr((this[_0xfa96[365]][_0xfa96[159]] + _0x8341xf) / 2)
              , _0x8341x17 = nr(0.41 * this[_0xfa96[365]][_0xfa96[126]])
              , _0x8341x21 = nr(0.65 * this[_0xfa96[365]][_0xfa96[126]]);
            this[_0xfa96[365]][_0xfa96[14]] = {
                x: _0x8341x16,
                y1: _0x8341x17,
                y2: _0x8341x21,
                font: _0x8341x15
            };
            var _0x8341x22 = nr(0.036 * this[_0xfa96[364]][_0xfa96[126]])
              , _0x8341x23 = nr(1.6 * _0x8341xf)
              , _0x8341x24 = nr(0.6 * _0x8341xf - _0x8341x22)
              , _0x8341x25 = nr(_0x8341x24 + 1.5 * _0x8341x22)
              , _0x8341x26 = nr(_0x8341x25 + 1.5 * _0x8341x22)
              , _0x8341x27 = nr(_0x8341x26 + 1.5 * _0x8341x22);
            this[_0xfa96[365]][_0xfa96[394]] = {
                x: _0x8341x23,
                y1: _0x8341x24,
                y2: _0x8341x25,
                y3: _0x8341x26,
                y4: _0x8341x27,
                font: _0x8341x22
            };
            var _0x8341x28 = nr(this[_0xfa96[364]][_0xfa96[159]] - _0x8341xf)
              , _0x8341x29 = nr(_0x8341x10)
              , _0x8341x2a = nr(0.036 * this[_0xfa96[364]][_0xfa96[126]])
              , _0x8341x2b = nr(_0x8341xf - 0.5 * _0x8341x2a)
              , _0x8341x2c = nr(_0x8341x10 + 1.5 * _0x8341x2a)
              , _0x8341x2d = nr(0.3 * _0x8341x2a)
              , _0x8341x2e = nr(_0x8341x10 - 0.5 * _0x8341x2a)
              , _0x8341x2f = nr(_0x8341xf + 0.5 * _0x8341x2a);
            this[_0xfa96[365]][_0xfa96[395]] = {
                x: _0x8341x28,
                y: _0x8341x29,
                font: _0x8341x2a,
                tx: _0x8341x2b,
                th: _0x8341x2d,
                ty: _0x8341x2c,
                lx: _0x8341x2f,
                ly: _0x8341x2e
			}
	}			